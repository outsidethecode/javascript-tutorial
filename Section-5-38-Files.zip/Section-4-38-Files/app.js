// Person Constructor
function Person(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
}

Person.prototype.sayHello = function() {
  return `Hello there! .. My name is ${this.firstName} ${this.lastName}`;
}

const rami = new Person('Rami', 'Naggar');

// console.log(rami);
console.log(rami.sayHello());

// Student Constructor
function Student(firstName, lastName, phone, matriculation) {
  Person.call(this, firstName, lastName);

  this.phone = phone;
  this.matriculation = matriculation;
}

// Inherit the Person prototype methods
Student.prototype = Object.create(Person.prototype);
// Make student.prototype return Student()
Student.prototype.constuctor = Student;

const sara = new Student('Sara', 'Haddad', 123456, 'AI1234');

Student.prototype.sayHello = function() {
  return `Hello there! .. Welcome to my university`;
}

//console.log(sara);
console.log(sara.sayHello());


