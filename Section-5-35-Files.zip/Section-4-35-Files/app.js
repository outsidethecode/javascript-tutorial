// function Person(name) {
//   this.name = name;
//   console.log(this);
// }

// const sara = new Person('Sara');
// const rami = new Person('Rami');

function Person(name, dateOfBirth) {
  this.name = name;
  this.birthday = new Date(dateOfBirth);
  this.getAge = function() {
    const difference = Date.now() - this.birthday.getTime();
    const ageDate = new Date(difference);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  }
}

const sara = new Person('Sara', '1-3-1995');
const rami = new Person('Rami', '3-5-1999');
const zak = new Person('Zak', '1-5-1999');

// console.log(sara);
// console.log(rami);
console.log(sara.name);
console.log(sara.getAge());