// Function Declaration
function sayHello() {
  console.log("Hello everyone!");
}

function greet(name = 'Rami') { // ES6
  // if (typeof name === 'undefined') name = "Rami";
  
  return "Hello " + name;
}

function rectangleArea(w, h) {
  return w * h;
}

//console.log(rectangleArea(10, 30));

// Function Expressions

const square = function(x = 10) {
  return  x * x;
};

//console.log(square());


// Immediately Invokable Function Expressions - IIFEs
// (function(name) {
//   console.log('Hello ' + name);
// })('Rami');

// Property Methods
const car = {
  price: 10,
  move: function() {
    console.log("Moving ... ");
  },
  accelerate: function(speed) {
    console.log("Speeding up to " + speed);
  }
}

car.break = function() {
  console.log('Break');
}

car.break();

