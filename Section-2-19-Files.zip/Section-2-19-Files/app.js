
//window.console.log("Hi");

//alert("Hello ..");
// const name = prompt("Enter your name");
// console.log("Hello " + name);

// const reply = confirm("Are you sure?");
// if (reply) {
//   console.log("Yes");
// } else {
//   console.log("No");
// }

// Window properties and methods
let value;
value = window.innerHeight;
value = window.innerWidth;

value = window.outerHeight;
value = window.outerWidth;

// Location object
value = window.location;
value = window.location.hostname;
value = window.location.port;
value = window.location.href;
value = window.location.search;

// Redirect
//window.location.href = 'http://www.google.com';

// Navigator object
value = window.navigator;
value = window.navigator.appVersion;
value = window.navigator.userAgent;
value = window.navigator.platform;
value = window.navigator.vendor;
value = window.navigator.language;












console.log(value);

