// Event Bubbling

// document.querySelector('.card-title').addEventListener('click', function() {
//   console.log('card-title');
// });

// document.querySelector('.card-content').addEventListener('click', function() {
//   console.log('card-content');
// });

// document.querySelector('.card').addEventListener('click', function() {
//   console.log('card');
// });

// Event Delegation

// const deleteElement = document.querySelector('.delete-item');
// deleteElement.addEventListener('click', deleteItem);

document.body.addEventListener('click', deleteItem);


function deleteItem(e) {
  // if (e.target.className === 'fa fa-remove') {
  //   console.log('delete item');
  // }

  // if (e.target.parentElement.className === 'delete-item secondary-content') {
  //   console.log('delete item');
  // }

  if (e.target.parentElement.classList.contains('delete-item')) {
    console.log('delete item');
    e.target.parentElement.parentElement.remove();
  }

}

