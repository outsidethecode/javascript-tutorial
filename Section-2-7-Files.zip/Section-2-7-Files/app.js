let value;
// Convert Number to String
value = String(3+3);

// Convert Bool to String
value = String(true);

// Convert Date to String
value = String(new Date());

// Convert Array to String
value = String([1,2,3]);

// Using toString()
value = (3).toString();
value = (true).toString();

// Convert String to Number
value = Number('33');
value = Number(true);
value = Number(false);
value = Number(null);
value = Number("hello");
value = Number([1,2,3]);

// Using parseInt() function
value = parseInt('30.30')
value = parseFloat('30.30')

const val1 = String(3);
const val2 = 5;
const sum = val1 + val2;
console.log(sum);

// Output 
// console.log(value);
// console.log(typeof value);
// //console.log(value.length);
// console.log(value.toFixed(2))

