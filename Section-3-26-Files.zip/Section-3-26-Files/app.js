
// Replace an element
const newTitle = document.createElement('h3');
newTitle.id = 'project-title';
newTitle.appendChild(document.createTextNode('Project List'));

const oldTitle = document.getElementById('project-title');
const parentCardAction = document.querySelector('.card-action');

parentCardAction.replaceChild(newTitle, oldTitle);

// Remove an element
const allLis = document.querySelectorAll('li');
const list = document.querySelector('ul.collection');

// allLis[1].remove();
// list.removeChild(allLis[2]);

// Adding/Removing classes 
const firstLi = document.querySelector('li:first-child');
const firstLink = firstLi.children[0];

let value;

value = firstLink.className;
value = firstLink.classList;
value = firstLink.classList[0];
firstLink.classList.add('my-class');
firstLink.classList.remove('delete-item');
value = firstLink;

// Adding/Removing attributes 
value = firstLink.getAttribute('href');
firstLink.setAttribute('href', 'http://www.google.com');
firstLink.setAttribute('title', 'Google');
firstLink.removeAttribute('title');
value = firstLink.hasAttribute('title');

console.log(value);