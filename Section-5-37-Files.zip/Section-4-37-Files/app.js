
//Object.prototype
//Person.prototype

// Person constructor
function Person(firstName, lastName, dateOfBirth) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.birthday = new Date(dateOfBirth);
  // this.getAge = function() {
  //   const difference = Date.now() - this.birthday.getTime();
  //   const ageDate = new Date(difference);
  //   return Math.abs(ageDate.getUTCFullYear() - 1970);
  // }
}

Person.prototype.getAge = function() {
  const difference = Date.now() - this.birthday.getTime();
  const ageDate = new Date(difference);
  return Math.abs(ageDate.getUTCFullYear() - 1970);
}

Person.prototype.getFullName = function() {
  return `${this.firstName} ${this.lastName}`
}

Person.prototype.getMarried = function(newLastName) {
  this.lastName = newLastName;
}

const sara = new Person('Sara', 'Haddad', '1-3-1995');
const rami = new Person('Rami', 'Naggar', '3-5-1999');

console.log(sara);
console.log(sara.getAge());
console.log(sara.getFullName());
sara.getMarried('Naggar');
console.log(sara.getFullName());

console.log(sara.hasOwnProperty('firstName'));


