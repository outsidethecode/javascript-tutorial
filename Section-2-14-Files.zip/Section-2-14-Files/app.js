// if (condition) {
//   do something
//   do something
//   do something
// } else {
//   do something else
//   do something else
//   do something else
// }

const number = 10;
// Equal to
// if (number == 10) {
//   console.log('Right');
// } else {
//   console.log('Wrong');
// }

// Not equal to
// if (number != 10) {
//   console.log('Right');
// } else {
//   console.log('Wrong');
// }

// Equal to value and Type
// if (number === 10) {
//   console.log('Right');
// } else {
//   console.log('Wrong');
// }

// Not Equal to value and Type
// if (number !== 10) {
//   console.log('Right');
// } else {
//   console.log('Wrong');
// }

// if (typeof number !== 'undefined') {
//   console.log(`The number is ${number}`);
// } else {
//   console.log('No number');
// }

// Greater/Less than (>, >=, <, <=) 
// if (number > 20) {
//   console.log("Greater than 20");
// } else {
//   console.log("Less than 20");
// }

// const fruit = 'Orange';
// if (fruit === 'Apple') {
//   console.log("My favourite fruit is Apple");
// } else if (fruit === 'Banana') {
//   console.log("My favourite fruit is Banana");
// } else {
//   console.log("My favourite fruit is not Apple or Banana");
// }

// Logical operator
const name = 'Rami';
const age = 35;

// And (&&)
// if (age > 0 && age < 12) {
//   console.log(`${name} is a child`);
// } else if (age >= 13 && age <= 19) {
//   console.log(`${name} is a teenager`);
// } else {
//   console.log(`${name} is an adult`);
// }

// OR (||)
if (age < 18 || age > 70) 
  console.log(`${name} cannot be registered`);
else 
  console.log(`${name} is acceptable`);


// Tenary operator
// console.log(number === 10 ? 'Yes' : 'No');










 




