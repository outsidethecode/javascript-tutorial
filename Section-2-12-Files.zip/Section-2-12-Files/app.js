const car = {
  price: 123,
  registrationNum: 'ABC123',
  automatic: true,
  yearModel: 2010,
  registeredAddress: {
    city: 'London',
    postCode: 'BN123W'
  },
  options: ['Cruise Control', 'Heated seats', 'Night vision'],
  getAge: function() {
    return 2019 - this.yearModel;
  }

}

let value;

value = car.registrationNum;
value = car['registrationNum'];
value = car.price;
value = car.automatic;
value = car.registeredAddress.city;
value = car.options[1];
value = car.getAge();



console.log(value);