
// Set local storage item
// localStorage.setItem('name', 'Rami');
// localStorage.setItem('age', '18');

// Set session storage item
// sessionStorage.setItem('name', 'Sara');
// sessionStorage.setItem('age', '25');

// Get from storage
// const name = localStorage.getItem('name');
// const age = localStorage.getItem('age');

// Remove from storage
//localStorage.removeItem('age');

// Clear local storage
//localStorage.clear();

// Submit form event listener
document.querySelector('form').addEventListener('submit', function(e) {
  const project = document.getElementById('project').value;

  //localStorage.setItem('project', project);
  
  let projects;

  if (localStorage.getItem('projects') === null) {
    projects = [];
  } else {
    projects = JSON.parse(localStorage.getItem('projects'));
  }

  projects.push(project);
  localStorage.setItem('projects', JSON.stringify(projects));

  e.preventDefault();
});

// Read project items from local storage

const projects = JSON.parse(localStorage.getItem('projects'));

projects.forEach(function (project) {
  console.log(project);
});