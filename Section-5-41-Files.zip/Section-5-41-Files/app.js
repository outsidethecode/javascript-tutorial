class Person {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  sayHello() {
    return `Hello there .. My name is ${this.firstName} ${this.lastName}`;
  }
}

class Student extends Person {
  constructor(firstName, lastName, phone, matriculation) {
    super(firstName, lastName);

    this.phone = phone;
    this.matriculation = matriculation;
  }

  static getUniName() {
    return 'Edinburgh University';
  }
}

const sara = new Person('Sara', 'Haddad');
console.log(sara);
const rami = new Student('Rami', 'Naggar', 123456, 'AI12345');
console.log(rami);
console.log(Student.getUniName());

