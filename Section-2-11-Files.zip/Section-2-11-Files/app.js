// Create a new Array
const numbers = [23, 4, 67, 89, 10, 7];
const anotherNumbers = new Array(34, 12, 9, 8, 16);
const languages = ['JavaScript', 'Java', 'Python', 'PHP', 'C#'];
const mixed = [12, 'JavaScript', null, true, new Date(), {a:1, b:2}];

let value;

// Get array length
value = numbers.length;

// Check if is Array
value = Array.isArray(numbers);

// Get a specific element
value = numbers[2];
value = numbers[0];
//numbers[2] = 100;

// Find index of value
value = numbers.indexOf(89);

// Arrays manipulation
// Add on to the end
//numbers.push(500);
// Add on to the front
//numbers.unshift(200);
// Take off from end
//numbers.pop();
// Take off from front
//numbers.shift();
// Splice 
//numbers.splice(1, 3);
// Reverse 
//numbers.reverse();

// Concatenate arrays
value = numbers.concat(anotherNumbers);

// Sorting arrays
value = languages.sort();
value = numbers.sort(function(x, y) {
  return x - y;
});

value = numbers.sort(function(x, y) {
  return y - x;
});













console.log(value);



