const make = 'Mercedes';
const model = 'E-Class';
const year = 2019;
const color = 'Silver';

let html;

// Tradtional way: ES5
html = '<ul><li>Make: ' + make + '</li><li>Model: ' + model + '</li><li>Year: ' + year + '</li><li>Color: ' + color + '</li></ul>';

html = '<ul>' + 
        '<li>Make: ' + make + '</li>' + 
        '<li>Model: ' + model + '</li>' + 
        '<li>Year: ' + year + '</li>' + 
        '<li>Color: ' + color + '</li>' + 
        '</ul>';


function sayHi() {
  return 'Hi';
}        
// With templates strings (ES6)

html = `
    <ul>
      <li>Make: ${make}</li>
      <li>Model: ${model}</li>
      <li>Year: ${year}</li>
      <li>Color: ${color}</li>
      <li>${year+1}</li>
      <li>${sayHi()}</li>
      <li>${year >= 2019 ? 'Brand new car' : 'Used car'}</li>
    </ul>  
`;

document.body.innerHTML = html;



