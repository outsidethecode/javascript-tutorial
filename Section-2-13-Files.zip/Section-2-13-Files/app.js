let value;

const today = new Date();

let birthday = new Date('8-27-1978');
birthday = new Date('8-27-1978 10:23:08');
// birthday = new Date('August 27 1977');
// birthday = new Date('8/28/1978');

value = birthday.getMonth();
value = birthday.getDate();
value = birthday.getDay();
value = birthday.getHours();
value = birthday.getMinutes();
value = birthday.getSeconds();
value = birthday.getTime();
value = birthday.getFullYear();

birthday.setMonth(2);
birthday.setDate(10);
birthday.setFullYear(1980);
birthday.setHours(9);
birthday.setMinutes(14);
birthday.setSeconds(33);


console.log(birthday);

