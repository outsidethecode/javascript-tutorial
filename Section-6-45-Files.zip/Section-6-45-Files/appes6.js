class Student {
  constructor(name, dob, matriculation) {
    this.name = name;
    this.dob = dob;
    this.matriculation = matriculation;
  }
}

class UI {
  addStudentToList(student) {
    const list = document.getElementById('student-list');
    // Create tr element
    const row = document.createElement('tr');
    // Insert cols
    row.innerHTML = `
      <td>${student.name}</td>
      <td>${student.dob}</td>
      <td>${student.matriculation}</td>
      <td><a href="#" class="delete">X<a></td>
    `;
  
    list.appendChild(row);
  }

  showAlert(message, className) {
    // Create div
    const div = document.createElement('div');
    // Add classes
    div.className = `alert ${className}`;
    // Add text
    div.appendChild(document.createTextNode(message));
    // Get parent
    const container = document.querySelector('.container');
    // Get form
    const form = document.querySelector('#student-form');
    // Insert alert
    container.insertBefore(div, form);

    // Timeout after 3 sec
    setTimeout(function(){
      document.querySelector('.alert').remove();
    }, 3000);
  }

  deleteStudent(target) {
    if(target.className === 'delete') {
      target.parentElement.parentElement.remove();
    }
  }

  clearFields() {
    document.getElementById('name').value = '';
    document.getElementById('dob').value = '';
    document.getElementById('matriculation').value = '';
  }
}

// Local Storage Class
class Store {
  static getStudents() {
    let students;
    if(localStorage.getItem('students') === null) {
      students = [];
    } else {
      students = JSON.parse(localStorage.getItem('students'));
    }

    return students;
  }

  static displayStudents() {
    const students = Store.getStudents();

    students.forEach(function(student){
      const ui  = new UI;

      // Add student to UI
      ui.addStudentToList(student);
    });
  }

  static addStudent(student) {
    const students = Store.getStudents();

    students.push(student);

    localStorage.setItem('students', JSON.stringify(students));
  }

  static removeStudent(matriculation) {
    const students = Store.getStudents();

    students.forEach(function(student, index){
     if(student.matriculation === matriculation) {
      students.splice(index, 1);
     }
    });

    localStorage.setItem('students', JSON.stringify(students));
  }
}

// DOM Load Event
document.addEventListener('DOMContentLoaded', Store.displayStudents);

// Event Listener for add student
document.getElementById('student-form').addEventListener('submit', function(e){
  // Get form values
  const name = document.getElementById('name').value,
        dob = document.getElementById('dob').value,
        matriculation = document.getElementById('matriculation').value

  // Instantiate student
  const student = new Student(name, dob, matriculation);

  // Instantiate UI
  const ui = new UI();

  console.log(ui);

  // Validate
  if(name === '' || dob === '' || matriculation === '') {
    // Error alert
    ui.showAlert('Please fill in all fields', 'error');
  } else {
    // Add student to list
    ui.addStudentToList(student);

    // Add to LS
    Store.addStudent(student);

    // Show success
    ui.showAlert('Student Added!', 'success');
  
    // Clear fields
    ui.clearFields();
  }

  e.preventDefault();
});

// Event Listener for delete
document.getElementById('student-list').addEventListener('click', function(e){

  // Instantiate UI
  const ui = new UI();

  // Delete student
  ui.deleteStudent(e.target);

  // Remove from LS
  Store.removeStudent(e.target.parentElement.previousElementSibling.textContent);

  // Show message
  ui.showAlert('Student Removed!', 'success');

  e.preventDefault();
});