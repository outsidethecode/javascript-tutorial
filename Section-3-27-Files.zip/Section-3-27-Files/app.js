
// document.querySelector('.clear-projects').addEventListener('click', function(e) {
//   console.log('Projects cleared');
// });

document.querySelector('.clear-projects').addEventListener('click', onClick);

function onClick(e) {
  console.log('Projects cleared');

  let value;

  value = e;
  value = e.target;
  value = e.target.className;
  value = e.target.classList;

  value = e.type;
  value = e.timeStamp;

  // Coordinates relative to the window
  value = e.clientX;
  value = e.clientY;

  // Coordinates relative to the element
  value = e.offsetX;
  value = e.offsetY;

  console.log(value);
}