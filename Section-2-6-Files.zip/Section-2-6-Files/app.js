
// Primitives

// String
const name = "Sara";
// Number
const age = 18;
// Boolean
const married = false;
// Null
let degree = null;
// undefined
let myVar;
// Symbol
const mySym = Symbol();


// Reference Types / Objects
// Array
const colors = ['blue', 'red'];
// Object literal
const person = {
  name: "Rami",
  age: 35
}
// Date
const today = new Date();

console.log(typeof today);





























