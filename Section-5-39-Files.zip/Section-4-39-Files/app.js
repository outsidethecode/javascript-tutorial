const prototypes = {
  sayHello: function() {
    return `Hello there .. My name is ${this.firstName} ${this.lastName}`;
  },
  getsMarried: function(newLastName) {
    this.lastName = newLastName;
  } 
}

const sara = Object.create(prototypes);
sara.firstName = 'Sara';
sara.lastName = 'Haddad';
sara.age = 25;

sara.getsMarried("Naggar");

console.log(sara);

const rami = Object.create(prototypes, {
  firstName: {value: 'Rami'},
  lastName: {value: 'Naggar'},
  age: {value: 30},
});

console.log(rami);
console.log(rami.sayHello());
