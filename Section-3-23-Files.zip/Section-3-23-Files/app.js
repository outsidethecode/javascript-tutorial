// document.getElementsByClassName

//const items = document.getElementsByClassName('collection-item');

// console.log(items[0]);
// items[0].style.color = "red";
// items[0].textContent = "Item 1";
// const allLis = document.querySelector('ul').getElementsByClassName('collection-item');
// console.log(allLis);

// document.getElementsByTagName
// let allLis = document.getElementsByTagName('li');
// allLis[0].style.color = "blue";

// // Convert HTML Collection into Array
// allLis = Array.from(allLis);
// console.log(allLis);

// allLis.forEach(function(li, index) {
//   console.log(li.className);
//   li.textContent = `Item ${index}`;
// });

// document.querySelectorAll
// const items = document.querySelectorAll('ul.collection li.collection-item');
// console.log(items);

// items.forEach(function(item, index) {
//   item.textContent = `Project #${index}`;
// });

const odds = document.querySelectorAll('li:nth-child(odd)');
const evens = document.querySelectorAll('li:nth-child(even)');

console.log(evens);
odds.forEach(function(li, index) {
  li.style.background = '#ccc';
});

evens.forEach(function(li, index) {
  li.style.background = '#f1f1f1';
});




