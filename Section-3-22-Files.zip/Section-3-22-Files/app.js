// document.getElementById()
// console.log(document.getElementById("Project-form"));
// console.log(document.getElementById("Project-form").id);
// console.log(document.getElementById("Project-form").className);


// const projectTile = document.getElementById("Project-title");
// console.log(projectTile);

// // Change content
// projectTile.textContent = "Project List";
// projectTile.innerText = "My Project List";
// projectTile.innerHTML = "<span style='color:gray'>My Projects</span>";

// // Change styling
// projectTile.style.background = "#ccc";
// projectTile.style.padding = "5px";
// //projectTile.style.display = 'none';

// document.querySelector()
// console.log(document.querySelector('#Project-title'));
// console.log(document.querySelector('.card-title'));
console.log(document.querySelector('h5'));

//document.querySelector('li').style.color = "blue";
// document.querySelector('ul li').style.color = "blue";

// document.querySelector('li:last-child').style.color = "red";
// document.querySelector('li:nth-child(3)').style.color = "yellow";
document.querySelector('li:nth-child(odd)').style.color = "red";

document.querySelector('li:nth-child(even)').style.color = "blue";









