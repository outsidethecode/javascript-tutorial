
let number1 = 10;
let number2 = 3;

let value;

// Simple math with numbers
value = number1 + number2;
value = number1 - number2;
value = number1 * number2;
value = number1 / number2;
value = number1 % number2;

// Math Object
value = Math.PI;
value = Math.round(3.4);
value = Math.ceil(3.4);
value = Math.floor(3.4);
value = Math.sqrt(9);
value = Math.abs(-8);
value = Math.pow(3,2);
value = Math.min(4, 6, 1, 7, 9);
value = Math.max(4, 6, 1, 7, 9);
value = Math.floor(Math.random() * 50 + 1);





console.log(value);