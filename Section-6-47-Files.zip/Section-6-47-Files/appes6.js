class Student {
  constructor(name, dob, matriculation) {
    this.name = name;
    this.dob = dob;
    this.matriculation = matriculation;
  }
}

class StudentsUI {
  addStudentToList(student) {
    const list = document.getElementById('student-list');
    const row = document.createElement('tr');
  
    row.innerHTML = `
      <td>${student.name}</td>
      <td>${student.dob}</td>
      <td>${student.matriculation}</td>
      <td><a href="#" class="delete">x</a></td>
    `;
  
    list.appendChild(row);
  }

  clearFields() {
    document.getElementById('name').value = '';
    document.getElementById('dob').value = '';
    document.getElementById('matriculation').value = '';
  }

  showAlert(message, className) {
    const div = document.createElement('div');
    div.className = `alert ${className}`;
    div.appendChild(document.createTextNode(message));
    const container = document.querySelector('.container');
    const form = document.querySelector('#student-form');
    container.insertBefore(div, form);  
  
    setTimeout(function() {
      document.querySelector('.alert').remove();
    }, 3000);
  }

  deleteStudent(target) {
    if (target.className === 'delete') {
      target.parentElement.parentElement.remove();
    }
  }
}

// Event Listeners
document.getElementById('student-form').addEventListener('submit', function(e) {

  const name = document.getElementById('name').value,
        dob = document.getElementById('dob').value,
        matriculation = document.getElementById('matriculation').value;

  // Instantiate student
  const student = new Student(name, dob, matriculation);
  // Instaniate StudentsUI
  const studentsUI = new StudentsUI();

  if (name === '' || dob === '' || matriculation === '') {
    studentsUI.showAlert('Please fill in all fields', 'error');
  } else {
    // Add student to list
    studentsUI.addStudentToList(student);
    // Clear fields
    studentsUI.clearFields();
    studentsUI.showAlert('Student added!', 'success');
  }

  e.preventDefault();
});

// Event listener for delete a student
document.getElementById('student-list').addEventListener('click', function(e) {

  // Instaniate StudentsUI
  const studentsUI = new StudentsUI();
  studentsUI.deleteStudent(e.target);
  studentsUI.showAlert('Student removed!', 'success');

  e.preventDefault();
});
