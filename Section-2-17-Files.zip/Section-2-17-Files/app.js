// For Loops

// for (let i = 0; i <= 10; i++) {
//   if (i === 3) {
//     console.log('Golden number');
//     continue;
//   }

//   if (i === 6) {
//     break;
//   }
//   console.log(i);
// }


// While Loops

// let i = 0;
// while (i <= 10) {
//   console.log(i);
//   i++;
// }

// Do While
// let i = 0;

// do {
//   console.log(i);
//   i++;
// } while (i <= 10);

// Loop through Array
const fruit = ['Apple', 'Banana', 'Orange', 'Pear']
// for (let i = 0; i < fruit.length; i++) {
//   console.log(fruit[i]);
// }

// foreach
// fruit.forEach(function(element) {
//   console.log(`Element is ${element}`);
// })

// // Map 
// const users = [
//   {id: 1, name: 'Rami'},
//   {id: 2, name: 'Ahmad'},
//   {id: 3, name: 'Sara'}
// ];

// const ids = users.map(function(user) {
//   return user.id;
// });

// console.log(ids);

// For in Loop
const user = {
  firstName: 'Rami',
  lastName: 'J',
  age: 40
}

for (let att in user) {
  console.log(`${att}: ${user[att]}`);
}
