
const clearButton = document.querySelector('.clear-projects');
const card = document.querySelector('.card');
const title = document.querySelector('h5');

//clearButton.addEventListener('click', handleEvent);

//clearButton.addEventListener('dblclick', handleEvent);

//clearButton.addEventListener('mousedown', handleEvent);

//clearButton.addEventListener('mouseup', handleEvent);

card.addEventListener('mouseenter', handleEvent);
card.addEventListener('mouseleave', handleEvent);

card.addEventListener('mouseover', handleEvent);
card.addEventListener('mouseout', handleEvent);

function handleEvent(e) {
  console.log(`Event type is '${e.type}'`);
  title.textContent = `MouseX: ${e.offsetX} - MouseY: ${e.offsetY}`;
}
