
// Global scope
var x = 1;
let y = 2;
const z = 3;

// function test() {
//   // Function scope
//   var x = 4;
//   let y = 5;
//   const z = 6;
//   console.log("Function scope", x, y, z);
// }

// test();

// if (true) {
//   // Block scope
//   var x = 4;
//   let y = 5;
//   const z = 6;
//   console.log("Block scope", x, y, z);
// }

for (let x=0; x<10; x++) {
  console.log(`Loop: ${x}`);
}


console.log("Global scope", x, y, z);
