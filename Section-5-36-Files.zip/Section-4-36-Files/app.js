
// String
const str1 = 'JavaScript';
const str2 = new String('JavaScript');
//str2.myProp = 'blah';
//console.log(str2);

// if (str2 === 'JavaScript') {
//   console.log('Correct');
// } else {
//   console.log('Not Correct');
// }

// Number
const number1 = 10;
const number2 = new Number(10);
//console.log(typeof number2);

// Boolean
const bool1 = true;
const bool2 = new Boolean(true);

//console.log(typeof bool2);

// Function
const mult1 = function(a, b) {
  return a * b;
}
const mult2 = new Function('a', 'b', 'return a * b');

//console.log(mult2(2, 4));

// Object 
const obj1 = {name: 'Rami'};
const obj2 = new Object({name: 'Rami'})
//console.log(obj2);

// Array
const array1 = [1, 2, 3];
const array2 = new Array(1, 2, 3);

console.log(array2);