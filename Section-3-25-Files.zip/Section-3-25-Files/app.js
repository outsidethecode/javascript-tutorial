// Create element
const li = document.createElement('li');

// Add class
li.className = 'collection-item';
// Add id
li.id = 'my-new-item';
// Set attribute
li.setAttribute('title', 'My new project');
li.appendChild(document.createTextNode('My New Project'));

// Create new link element
const link = document.createElement('a');

// Add class
link.className = "delete-item secondary-content";

// Add icon html
link.innerHTML = '<i class="fa fa-remove"></i>';

// Append link into li
li.appendChild(link);

// Append li as child to ul
document.querySelector('ul.collection').appendChild(li);

console.log(li);